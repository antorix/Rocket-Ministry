from main import app
app()
