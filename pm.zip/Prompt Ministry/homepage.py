#!/usr/bin/python
# -*- coding: utf-8 -*-

import io2       
import territory
import contacts
import dialogs
import reports
import set
import notebook
import console
from icons import icon

def homepage(houses, settings, resources):
    """ Home page """
    
    while 1:
            
            # Prepare data
            
            reports.report(houses, settings, resources, stop=True) # check new month
            
            if reports.updateTimer(settings[2][6])>=0: time = reports.updateTimer(settings[2][6])
            else: time = reports.updateTimer(settings[2][6]) + 24
            
            if settings[2][6] > 0: timerTime = " \u2b1b %0.2f ч." % time # check if timer is on to show time
            else: timerTime=" \u25b6"
            
            if settings[0][8]==1 and settings[2][11]==1: # report reminder
                remind = icon("lamp", settings[0][4])
            else: remind=""
            
            appointment = "" # сounting contacts and check closest appointment date, if enabled
            totalContacts, datedFlats = contacts.getContactsAmount(houses, resources, settings[0][11])
            if len(datedFlats)>0: appointment = icon("appointment", settings[0][4])
            else: appointment = ""
            
            options = [
                    icon("timer", settings[0][4])   + " Таймер" + timerTime,
                    icon("report", settings[0][4])  + " Отчет (%0.2f ч.)  %s" % (settings[2][0], remind),
                    icon("globe", settings[0][4])   + " Участки (%d)" % len(houses),
                    icon("contacts", settings[0][4])+ " Контакты (%d)  %s" % (totalContacts, appointment),
                    icon("notebook", settings[0][4])+ " Блокнот (%d)" % len(resources[0]),
                    icon("console", settings[0][4]) + " Консоль",
                    icon("tools", settings[0][4])   + " Инструменты"
                ]
            
            if io2.osName != "android": options.append(icon("preferences", settings[0][4]) + " Настройки") # neutral button on Android
            
            # Run home screen
            
            try:
                choice = dialogs.dialogList( # display list of houses and options
                form = "main",
                title = icon("rocket", settings[0][4]) + " Prompt Ministry " + reports.getTimerIcon(settings[2][6], settings), # houses sorting type, timer icon
                message = "Выберите раздел:",
                options = options,
                cancel = "Выход",
                neutral = icon("preferences", settings[0][4]) + " Настройки",
                neutralButton = True)
            except:
                io2.log("Ошибка вывода")
                return
            
            if choice==None: # exit
                choice2 = dialogs.dialogConfirm(
                    title = icon("rocket", settings[0][4]) + " Prompt Ministry " + reports.getTimerIcon(settings[2][6], settings),
                    message = "Действительно выйти?"
                )
                if choice2 == True: return True
                else: continue
                
            elif choice=="neutral": set.preferences(houses, settings, resources) # program settings
                
            elif choice==0: # start/stop timer
                if settings[2][6] == 0: reports.report(houses, settings, resources, choice="%(")
                else: reports.report(houses, settings, resources, choice="%)")
                
            elif choice==1: reports.report(houses, settings, resources) # report
                
            elif choice==2: territory.terView(houses, settings, resources) # territory
                
            elif choice==3: contacts.showContacts(houses, settings, resources) # contacts
                
            elif choice==4: notebook.showNotebook(houses, settings, resources) # notebook
                
            elif choice==5: console.dialog(houses, settings, resources) # console
                    
            elif choice==6: houses, settings, resources, exit = set.tools(houses, settings, resources) # tools
