#!/usr/bin/python
# -*- coding: utf-8 -*-

import io2
import reports
import time
import os
from icons import icon

if io2.osName == "android":
    from androidhelper import Android
    phone = Android()
else: from easygui_mod import enterbox, choicebox, buttonbox, filesavebox, codebox

def dialog(title="", message="", default="", ok="Ввод", cancel="Назад", neutralButton=False, neutral=""):
    """ Console input """
    
    if io2.osName == "android":        
        phone.dialogCreateInput(title, message, default)
        phone.dialogSetPositiveButtonText(ok)
        phone.dialogSetNegativeButtonText(cancel)
        if neutralButton == True: phone.dialogSetNeutralButtonText(neutral)
        phone.dialogShow()
        resp = phone.dialogGetResponse()[1]
        phone.dialogDismiss()
        if "canceled" in resp and resp["value"]=="": return None
        elif "canceled" in resp and resp["value"]!="": return "cancelled!" + resp["value"]
        elif "neutral" in resp["which"]: return "neutral"
        elif "positive" in resp["which"]: return resp["value"]
        else: return None
        
    else:
        choice = enterbox(message, title, default, neutralButton=neutralButton, neutral=neutral)
        return choice

def dialogRadio(title="", options=[], selected=0, message="", positive="OK"):
    
    if io2.osName=="android":
        phone.dialogCreateAlert(title, message)
        phone.dialogSetSingleChoiceItems(options, selected)
        phone.dialogSetPositiveButtonText(positive)        
        phone.dialogShow()
        phone.dialogGetResponse()
        resp = phone.dialogGetSelectedItems()[1]        
        return resp
        
    else:
        resp = choicebox(title=title, msg=message, choices=options)
        return resp

def dialogList(title="", message="", close=True, options=[], positiveButton=False, positive="\ud83d\udcbb Консоль", neutralButton=False, neutral="Настройки", cancel="Назад", form="", selectedHouse=0, houses=[], settings=[]):
    """ List """
    
    if io2.osName=="android":
        phone.dialogCreateAlert(title, "")
        phone.dialogSetItems(options)
        phone.dialogSetNegativeButtonText(cancel)
        if positiveButton == True: phone.dialogSetPositiveButtonText(positive)
        if neutralButton == True: phone.dialogSetNeutralButtonText(neutral)
        phone.dialogShow()
        resp = phone.dialogGetResponse()[1]
        phone.dialogDismiss()       
        if "canceled" in resp: return None
        elif "item" in resp: return resp["item"]
        elif "positive" in resp["which"]: return "positive"
        elif "neutral" in resp["which"]: return "neutral"            
        else: return None
        
    else:
        choice = choicebox(message, title, options)         # Input results:
        
        if choice==None:                                    return None # exit
        
        elif "Участки" in choice and form!="main":          return "neutral" # buttons when not in Android
        elif "Участок" in choice and form=="houseView":     return "neutral"
        elif "Настройки" in choice and form=="main":        return "neutral"
        elif "Квартира" in choice:                          return "neutral"
        elif "Сотрудник" in choice:                         return "neutral"
        elif "Расчеты" in choice:                           return "neutral"
        elif "Запись" in choice:                            return "neutral"
        elif reports.monthName()[2] in choice\
            and form!="serviceYear":                        return "neutral" # last month in report
        elif "Экспорт" in choice and form=="showNotebook":  return "neutral"
        elif "Сортировка" in choice\
            and form!="porchSettings":                      return "neutral" # sorting contacts or houses
        
        elif "Консоль" in choice and not "Консольн" in choice\
            and form!="main":                               return "positive"
        
        elif form=="terView":                                        
            if "\u2795" in choice or "+" in choice:         return 0
            else:
                for i in range(len(houses)):
                    if houses[i].title in choice:           return i+1
                    
        elif form=="houseView":                                      
            if "\u2795" in choice or "+" in choice:         return 0
            else:
                for i in range(len(houses[selectedHouse].porches)):
                    if houses[selectedHouse].porches[i].title in choice: return i+1     
        
        else:
            for i in range(len(options)):
                if options[i] in choice:                    return i
        
def dialogConfirm(title="", message="", neutralButton=False, choices=["Да", "Возможно", "Нет"]):
    """ Yes or no """
    
    if io2.osName=="android":
        phone.dialogCreateAlert(title, message)
        phone.dialogSetPositiveButtonText(choices[0])
        phone.dialogSetNegativeButtonText(choices[2])
        if neutralButton == True: phone.dialogSetNeutralButtonText(choices[1])
        phone.dialogShow()
        response=phone.dialogGetResponse().result
        phone.dialogDismiss()
        if "which" in response:
            if response["which"]=="positive": return True
            if response["which"]=="negative": return False
            if response["which"]=="neutral":  return "neutral"                        
    else:
        if neutralButton == True: result = buttonbox(message, title, choices)
        else: result = buttonbox(message, title, [choices[0], choices[2]])
        if result==choices[0]: return True
        if result==choices[1]: return "neutral"
        if result==choices[2]: return False
        
def dialogInfo(title="", message="", neutralButton=False, neutral="", no="Назад"):
    """ Simple information windows """
    
    if io2.osName=="android":
        phone.dialogCreateAlert(title, message)
        if neutralButton == True: phone.dialogSetNeutralButtonText(neutral)
        phone.dialogSetNegativeButtonText(no)
        phone.dialogShow()
        response = phone.dialogGetResponse().result
        phone.dialogDismiss()
        if "which" in response:
            if response["which"]=="negative": return False
            if response["which"]=="neutral":  return "neutral"  
            
    else:
        buttonbox(message, title, ["Назад"])
        
def dialogHelp(title="", message=""):    
    """ Help dialog """
    
    if io2.osName=="android":
        phone.dialogCreateAlert(title, message)
        phone.dialogSetNegativeButtonText("Назад")
        phone.dialogShow()
        phone.dialogGetResponse().result
        phone.dialogDismiss()
        
    else:
        #msgbox(message, title, "Назад")
        codebox(title=title, msg="", text=message)

def pickDate(title="",
            settings=[],
            year = int( time.strftime("%Y", time.localtime()) ),
            month = int( time.strftime("%m", time.localtime()) ),
            day = int( time.strftime("%d", time.localtime()) )
        ):

    if io2.osName=="android":
        phone.dialogCreateDatePicker(year, month, day)
        phone.dialogSetPositiveButtonText("OK")
        phone.dialogSetNegativeButtonText("Отмена")
        phone.dialogShow()
        response = phone.dialogGetResponse()[1]
        phone.dialogDismiss()
        os.system("clear")
        #print(response)
        #input()
        if "positive" in response["which"]: return "%s-%02d-%02d" % (str(response["year"]), response["month"], response["day"])
        else: return None
        
    else:
       response = enterbox(msg="Введите дату в формате ГГГГ-ММ-ДД:", title = icon("date", settings[0][4]) + " Дата взятия участка", default="%04d-%02d-%02d" % (year, month, day)) 
       return response

def dialogFileSave(msg="", title="", default="data.jsn", filetypes= "\*.jsn"):
    
    if io2.osName=="android": return
    else:
        choice = filesavebox(msg,title,default,filetypes)
        return choice
