#!/usr/bin/python
# -*- coding: utf-8 -*-
version = "1.3.2"
import io2
import homepage
import sys

def app():
    """ Callable program """
    
    # Load
    houses, settings, resources = io2.load()
    
    # Check arguments
    if "--import" in sys.argv: houses, settings, resources = io2.load(url=settings[0][14])
    
    # Stop spinning picture    
    if io2.osName == "android":
        from androidhelper import Android
        Android().dialogDismiss()

    # Run homepage  
    homepage.homepage(houses, settings, resources) 

    # Exit
    """if io2.osName == "android":
        os.system("clear")
        print("Нажмите Enter для выхода. Приходите еще!")
    else: print("Успешный выход")"""

# Start program app

if __name__ == "__main__":
    app()
