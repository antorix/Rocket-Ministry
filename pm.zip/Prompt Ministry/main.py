#!/usr/bin/python
# -*- coding: utf-8 -*-

global version
version = "1.3.1"

# Show spinning progress

import io2
import homepage
import os

def app(pathA):
    """ Callable program """
    
    """if io2.osName=="android":
        from androidhelper import Android
        phone = Android()
        phone.dialogCreateSpinnerProgress(title="\ud83d\ude80 Prompt Ministry", message="Зажигание", maximum_progress=100)
        phone.dialogShow()"""

    # Modify database path on Android by outside script

    if pathA != "": 
        io2.AndroidUserPath = pathA
        io2.log("Using on Android: %s" % io2.AndroidUserPath)
    
    houses, settings, resources = io2.load()
    
    """ # Check if datafile import is needed
    
    if io2.osName!="android":
        try:
            with open("data.jsn", "r") as file: url = json.load(file)[1][0][14] # retreive import path from datafile
        except: houses, settings, resources = io2.load()
        else: houses, settings, resources = io2.load(url=url)
    else: # disabled on Android
        houses, settings, resources = io2.load() """
    
    # Stop spinning picture
    
    if io2.osName == "android":
        from androidhelper import Android
        Android().dialogDismiss()

    # Run homepage  

    homepage.homepage(houses, settings, resources) 

    # Exit

    if io2.osName == "android":
        os.system("clear")
        print("Нажмите Enter для выхода. Приходите еще!")
    else: print("Успешный выход")

# Start program app

if __name__ == "__main__":
    app(pathA="")
